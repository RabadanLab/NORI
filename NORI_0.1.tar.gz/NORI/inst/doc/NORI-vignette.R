## ---- eval = FALSE-------------------------------------------------------
#  # load package
#  library(NORI)
#  
#  # define paths
#  gtf_path <- "./merged.gtf"                          # input GTF
#  ens_path <- "./Homo_sapiens.GRCh37.75.gtf"          # Ensembl reference
#  refseq_path <- "./RefSeq-GRCh37-hg19.bed"           # RefSeq reference
#  pseudo_path <- "./Human74.bed"                      # Pseudogene build
#  ref_fa <- "./hg19.fa"                               # Reference assembly for CPAT
#  bam_paths <- list.files(path = ".",
#  	pattern = "[.]bam$", full.names = TRUE)     # character vector of paths to BAM files
#  
#  # run NORI
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa_path, bam_paths)

## ---- eval = FALSE-------------------------------------------------------
#  lnc_list <- NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths)

## ---- eval = FALSE-------------------------------------------------------
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths,
#      output_dir = "./output", logs_path = "./output/logs.txt")

## ---- eval = FALSE-------------------------------------------------------
#  # skip Pseudogene step
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths, filter_pseudogenes = FALSE)

## ---- eval = FALSE-------------------------------------------------------
#  # skip existing files
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths, overwrite = FALSE)

## ---- eval = FALSE-------------------------------------------------------
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths,
#      cpat_cutoff = 0.370)

## ---- eval = FALSE-------------------------------------------------------
#  logit_model <- system.file("extdata", "Human_train.RData", package = "NORI")
#  hexamer_dat <- system.file("extdata", "Human_Hexamer.tab", package = "NORI")

## ---- eval = FALSE-------------------------------------------------------
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths,
#      logit_model = "./logit_model.RData", hexamer_dat = "./hexamer_dat.tab")

## ---- eval = FALSE-------------------------------------------------------
#  num_samples <- length(bam_paths)
#  new_threshold <- 0.01 * num_samples
#  
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths,
#      rpkm_threshold = new_threshold)

## ---- eval = FALSE-------------------------------------------------------
#  NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, bam_paths, nthreads = 4)

## ---- eval = FALSE-------------------------------------------------------
#  # run the NORI pipeline up to the RPKM step
#  # we do not need to pass bam_paths since RPKM is not calculated here
#  lnc_list <- NORI(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa, filter_rpkm = FALSE)

## ---- eval = FALSE-------------------------------------------------------
#  # choose output directory for read counts
#  read_counts_output_dir <- "./read_counts"
#  
#  # select last BED path to be used for read counts
#  penultimate <- lnc_list[length(lnc_list)]
#  
#  # calculate read counts
#  read_counts_sge <- function(penultimate, bam_paths, read_counts_output_dir) {

## ---- eval = FALSE-------------------------------------------------------
#  # after the jobs complete, get other components of RPKM and filter
#  #     according to passed or default threshold
#  num_cores <- 4 # optional
#  rpkm_threshold <- 0.05 * length(bam_paths) # optional
#  
#  # select only read counts outputs (not summaries)
#  # adjust the contents of list.files() according to your files
#  read_counts_paths <- list.files(read_counts_output_dir, pattern = "TCGA", full.names = TRUE)
#  read_counts_paths <- read_counts_paths[!grepl(".summary", read_counts_paths)]
#  
#  # finally, aggregate outputs to determine RPKM and filter according to chosen threshold
#  rpkm <- calculate_rpkm_sge(read_counts_paths, num_cores = num_cores, write_rpkm_to_file = TRUE)
#  final <- filter_rpkm(rpkm, penultimate, rpkm_threshold)
#  

