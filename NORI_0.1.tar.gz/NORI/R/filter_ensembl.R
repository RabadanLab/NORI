#' Remove transcripts annotated as coding in Ensembl
#'
#' Remove transcripts annotated as "lincRNA", "non_coding", "antisense", "3prime_overlapping_ncrna", "processed_transcript", "miRNA", "misc_RNA", "polymorphic_pseudogene", "processed_pseudogene", or "pseudogene".
#'
#' @param bed_path path to BED file
#' @param ref_path path to Ensembl reference
#' @param intersect_args additional arguments to be sent to bedtools intersect. "-nonamecheck", "-split", and "-v" are automatically passed.
#' @param logs_path path to log file. Defaults to the file "ensembl_log" saved in the same directory as \code{bed_path}. Logs can be suppressed by passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to resulting BED file
#'
#' @import data.table
#' @importFrom tools file_path_sans_ext file_ext
#' @export

filter_ensembl <- function(bed_path, ref_path, intersect_args = NULL, logs_path = "default", quiet = FALSE) {
    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(dirname(bed_path), "/ensembl_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    if (!quiet) {
        cat("\n*** Filtering transcripts found in specified Ensembl assembly ***\n\n")
    }
    # check if chromosome naming scheme is "chr1", "chr2",... or "1", "2", ...
    chrom_names <- unique(fread(paste("awk 'NR > 5'",ref_path, "| awk '{print $1}'"), header = FALSE))
    starts_with_chr <- chrom_names[, any(grepl(pattern = "^chr[1-9]", V1))]
    if (!quiet) {
        cat("    Identifying transcripts annotated as coding...")
    }
    # get the coding transcripts in gtf format so they may later be removed
    # start with sixth line to skip the header
    ref_coding_path <- paste0(file_path_sans_ext(ref_path), "_coding.", file_ext(ref_path))
    if (starts_with_chr) {
        cmd <- paste("awk 'NR > 5'", ref_path,
        "| awk '$2 !~ /lincRNA|non_coding|antisense|3prime_overlapping_ncrna|processed_transcript|miRNA|misc_RNA|polymorphic_pseudogene|processed_pseudogene|pseudogene/' >",
        ref_coding_path)
    } else {
        cmd <- paste("awk 'NR > 5'", ref_path,
        "| awk '$2 !~ /lincRNA|non_coding|antisense|3prime_overlapping_ncrna|processed_transcript|miRNA|misc_RNA|polymorphic_pseudogene|processed_pseudogene|pseudogene/' | sed 's:^:chr:' >",
        ref_coding_path)
    }
    system(cmd)
    if (!quiet) {
        cat(" done\n")
    }
    # intersect cuffmerge output with passed Ensembl gtf
    if (!quiet) {
        cat("    Calling bedtools intersect...")
    }
    out_path <- paste0(file_path_sans_ext(bed_path),"_ens.", file_ext(bed_path))
    bedtools_intersect(a = bed_path, b = ref_coding_path,
        out_path = out_path, args = c("-nonamecheck", "-split", "-v", intersect_args))
    if (!quiet) {
        cat(" done\n")
        num_lines_ref_coding <- strsplit(system(paste("wc -l", ref_coding_path),
            intern = TRUE), split = ' ')[[1]][1]
        num_lines_bed <- strsplit(system(paste("wc -l", bed_path),
            intern = TRUE), split = ' ')[[1]][1]
        num_lines_out <- strsplit(system(paste("wc -l", out_path),
            intern = TRUE), split = ' ')[[1]][1]
        cat("\n    Summary\n",
            "    Inputs\n        ",
            basename(bed_path), ":", num_lines_bed, "transcripts\n        ",
            basename(ref_coding_path), ":", num_lines_ref_coding, "transcripts\n",
            "    Output\n        ",
            basename(out_path), ":", num_lines_out, "transcripts\n\n")
        cat("\n    File (", basename(out_path), ") written to: ", dirname(out_path), "\n", sep = "")
        cat("_____________________________________________________________________________\n")
    }
    if (!is.null(logs_path)) {
        sink()
    }
    invisible(out_path)
}
