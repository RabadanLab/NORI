#' Get read counts using a Sun Grid Engine cluster
#'
#' @param bed_path path to BED file
#' @param bam_paths character vector of file paths to bam files
#' @param output_dir path to output directory.
#' @param args arguments for featureCounts. Defaults to "-p", "-s 0", "-B"
#' @param mem memory allocated for each SGE job. Defaults to 1 (GB)
#' @param overwrite choose whether existing read counts outputs should be overwritten. Defaults to TRUE
#' @param quiet suppress logs if TRUE. Defaults to FALSE
#'
#' @return NULL
#'
#' @export
#'
#' @import data.table

read_counts_sge <- function(bed_path, bam_paths, output_dir, args = c("-p", "-s 0", "-B"), mem = 1, overwrite = TRUE, quiet = FALSE) {

    # summarize data to the gene level, convert to BED, and write GTF to file for featureCounts
    gtf_path <- bed_to_gtf_by_gene_annot(bed_path)

    # get read counts using featureCounts by submitting individual jobs to the SGE cluster
    get_read_counts_sge(bam_paths, gtf_path, output_dir,
        args, mem, overwrite, quiet)

}
