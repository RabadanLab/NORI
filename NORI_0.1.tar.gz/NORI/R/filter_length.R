#' Remove transcripts of length <200bp
#'
#' @param bed_path path to BED file
#' @param logs_path path to log file. Defaults to the file "length_log" saved in the same directory as \code{bed_path}. Logs can be suppressed by passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to resulting BED file
#'
#' @import data.table
#' @importFrom tools file_path_sans_ext file_ext
#' @export

filter_length <- function(bed_path, logs_path = "default", quiet = FALSE) {

    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(dirname(bed_path), "/length_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    if (!quiet) {
        cat("\n*** Filtering trancripts shorter than 200nt ***\n\n")
    }

    # read file, calculate length, keep > 200nt
    bed <- fread(bed_path, header = FALSE)
    split <- strsplit(bed$V11, ",")
    lengths <- vapply(split, FUN = function(x) sum(as.numeric(x)), FUN.VALUE = numeric(1))
    bed_long <- bed[lengths > 200]

    # write file
    out_path <- paste0(file_path_sans_ext(bed_path), "_length.", file_ext(bed_path))
    write.table(bed_long, file = out_path, sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)

    # logs
    if (!quiet) {
        cat(" done\n")
        cat("\n    Summary\n\n",
            "    Inputs\n        ",
            basename(bed_path), ":", nrow(bed), "transcripts\n",
            "    Output\n        ",
            basename(out_path), ":", nrow(bed_long), "transcripts\n\n",
            "    File written to:", dirname(out_path),
            "\n")
        cat("_____________________________________________________________________________\n")
    }
    if (!is.null(logs_path)) {
        sink()
    }
    invisible(out_path)
}
