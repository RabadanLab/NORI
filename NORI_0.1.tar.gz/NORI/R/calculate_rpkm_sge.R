#' Calculate RPKM using a Sun Grid Engine cluster
#'
#' @param gtf_path file path to GTF input
#' @param bam_paths character vector of file paths to bam files
#' @param num_cores number of cores to use for parallelized foreach call
#'
#' @return NULL
#'
#' @export
#'
#' @import data.table
#' @import doParallel
#' @importFrom foreach %dopar%

calculate_rpkm_sge <- function(read_counts_paths, gene_or_transcript = "gene", num_cores = 2, write_rpkm_to_file = TRUE) {

    doParallel::registerDoParallel(cores = num_cores)
    rpkm <- foreach (i = seq_along(read_counts_paths)) %dopar% {
        tmp <- fread(paste("awk 'NR > 1'", read_counts_paths[i], "| cut -f 1,6,7"))
        if (gene_or_transcript == "gene") {
	    setnames(tmp, c("gene_id", "length", "reads"))
	} else if (gene_or_transcript == "transcript") {
            setnames(tmp, c("transcript_id", "length", "reads"))
	} else {
	    stop("need to specify gene or transcript")
	}
        tmp[, `:=`(kilobase_transcript = length / 1e3, million_mapped_reads = sum(reads) / 1e6)]
        tmp[, `:=`(rpkm = (reads / kilobase_transcript / million_mapped_reads), sample = basename(read_counts_paths[i])) ]
        tmp
    }

    rpkm <- rbindlist(rpkm)
    if (write_rpkm_to_file) {
        write.table(rpkm, file = "./rpkm.tsv", quote = FALSE, row.names = FALSE, col.names = TRUE, sep = "\t")
    }

    rpkm
}
