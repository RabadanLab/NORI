#' Wrapper around bedtools intersect system call
#'
#' Define a wrapper to easily call bedtools intersect with optional arguments
#' and output path
#'
#' @param a file in BAM/BED/GFF/VCF format to compare to b
#' @param b file in BAM/BED/GFF/VCF format to compare to a
#' @param out_path optional path to output file
#' @param args optional arguments passed as a character vector
#'
#' @return invisibly return output of bedtools intersect call (if \code{out_path})
#' is NULL
#'
#' @export
bedtools_intersect <- function(a, b, out_path = NULL, args = "") {
    if (Sys.which("bedtools") == "") {
        stop("bedtools was not found on the system path. Please add it to the path and try again.")
    }
    args <- paste(args, collapse = " ")
    if (length(out_path) > 0) {
        cmd <- paste("bedtools intersect", args, "-a", a, "-b", b, ">", out_path)
    } else {
        cmd <- paste("bedtools intersect", args, "-a", a, "-b", b)
    }
    output <- system(cmd, intern = TRUE)
    invisible(output)
}
