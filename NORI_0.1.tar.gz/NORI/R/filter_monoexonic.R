#' Remove monoexonic transcripts
#'
#' Uses the blockCount value in column 10 of the BED file to select
#' transcripts which have more than one exon.
#'
#' @param bed_path path to BED file
#' @param logs_path optional path to log file. Defaults to "monoexonic_log" saved in
#' the same directory as \code{bed_path}. Logs can be suppressed by passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to resulting BED file
#'
#' @import data.table
#' @importFrom tools file_path_sans_ext file_ext
#' @export

filter_monoexonic <- function(bed_path, logs_path = "default", quiet = FALSE) {
    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(dirname(bed_path), "/monoexonic_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    if (!quiet) {
        cat("\n*** Filtering mono-exonic transcripts ***\n\n")
        cat("    Reading files...")
    }
    bed <- fread(bed_path, header = FALSE, col.names = c("chrom", "start", "end",
        "transcript_id", "score", "strand", "thickStart", "thickEnd", "rgb",
        "blockCount", "blockSizes", "blockStarts"))
    if (!quiet) {
        cat(" done\n")
        cat("    Identifying multi-exonic transcripts...")
    }
    bed_multiexon <- bed[blockCount > 1]
    if (!quiet) {
        cat(" done\n")
        cat("    Writing data...")
    }
    out_path <- paste0(file_path_sans_ext(bed_path), "_me.", file_ext(bed_path))
    write.table(bed_multiexon, file = out_path, sep = "\t", row.names = FALSE,
        col.names = FALSE, quote = FALSE)
    if (!quiet) {
        cat(" done\n")
        cat("\n    Summary\n",
            "    Inputs\n        ",
            basename(bed_path), ":", nrow(bed), "transcripts\n",
            "    Output\n        ",
            basename(out_path), ":", nrow(bed_multiexon), "transcripts\n\n")
        cat("\n    File (", basename(out_path),  ") written to: ", dirname(out_path),
            "\n", sep = "")
        cat("_____________________________________________________________________________\n")
    }
    if (!is.null(logs_path)) {
        sink()
    }
    invisible(out_path)
}
