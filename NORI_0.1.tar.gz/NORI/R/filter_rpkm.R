#' Remove transcripts with low RPKM
#'
#' Transcripts with an RPKM less than the chosen cutoff are filtered. This function requires a BED12 input.
#'
#' @param rpkm output from \code{calculate_rpkm}
#' @param bed_path path to BED file
#' @param filter_by filter at the gene level by default. Can pass "transcript" to filter at the transcript level
#' @param rpkm_threshold chosen RPKM threshold. Omit or pass NULL to use default of 0.05 * number of samples
#' @param logs_path path to log file. Defaults to the file "rpkm_log" saved in the same directory as \code{bed_path}. Logs can be suppressed by passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to resulting BED file
#'
#' @import data.table
#' @importFrom tools file_path_sans_ext file_ext
#' @export

filter_rpkm <- function(rpkm, bed_path, filter_by = "gene", rpkm_threshold = NULL, logs_path = "default",
    quiet = FALSE) {
    #-----SETUP-----#
    stopifnot(filter_by == "gene" | filter_by == "transcript")

    # set rpkm threshold to default value if not explicitly set
    if (is.null(rpkm_threshold)) {
        rpkm_threshold <- length(unique(rpkm$sample)) * 0.05
    }
    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(dirname(bed_path), "/rpkm_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    if (!quiet) {
        cat("\n*** Filtering by RPKM ***\n\n")
        cat("    Reading files...")
    }
    bed <- fread(bed_path, header = FALSE)
    if (ncol(bed) == 13) {
        setnames(bed, c("chrom", "start", "end",
            "transcript_id", "score", "strand", "thickStart", "thickEnd", "rgb",
            "blockCount", "blockSizes", "blockStarts", "gene_id"))
    } else {
        stop("this is not a BED12 with gene identifiers file")
    }

    if (!quiet) {
        cat(" done\n")
        cat("    Removing poorly expressed transcripts...")
    }

    if (filter_by == "gene") {
        rpkm_genes_to_keep <- rpkm[, .(max_rpkm = max(rpkm)), by = gene_id][
            max_rpkm > rpkm_threshold, gene_id]
        bed_rpkm <- bed[bed$gene_id %in% rpkm_genes_to_keep]
    } else if (filter_by == "transcript") {
        rpkm_transcripts_to_keep <- rpkm[, .(max_rpkm = max(rpkm)), by = transcript_id][
            max_rpkm > rpkm_threshold, transcript_id]
        bed_rpkm <- bed[bed$transcript_id %in% rpkm_transcripts_to_keep]
    }

    if (!quiet) {
        cat(" done\n")
        cat("    Writing data...")
    }

    out_path <- paste0(file_path_sans_ext(bed_path), "_rpkm.", file_ext(bed_path))
    write.table(bed_rpkm, file = out_path, sep = "\t", row.names = FALSE,
        col.names = FALSE, quote = FALSE)

    #! write rpkm threshold to log file
    if (!quiet) {
        cat(" done\n")
        cat("\n    Summary\n",
            "    Inputs\n        ",
            basename(bed_path), ":", nrow(bed), "transcripts\n",
            "    Output\n        ",
            basename(out_path), ":", nrow(bed_rpkm), "transcripts\n\n")
        cat("\n    File (", basename(out_path),  ") written to: ", dirname(out_path),
            "\n", sep = "")
        cat("_____________________________________________________________________________\n")
    }
    if (!is.null(logs_path)) {
        sink()
    }
    invisible(out_path)
}
