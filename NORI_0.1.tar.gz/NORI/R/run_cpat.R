#' Run CPAT to determine transcript coding potential
#'
#' @param bed_path path to BED file
#' @param ref_fa path to reference assembly for CPAT in FASTA format
#' @param logit_model path to logit model for CPAT. Omit or pass NULL to use CPAT default "Human_train.RData"
#' @param hexamer_dat path to hexamer data file for CPAT. Omit or pass NULL to use CPAT default "Human_Hexamer.tab"
#' @param logs_path path to log file. Defaults to the file "run_cpat_log" saved within the same folder as \code{bed_path}. Logs can be suppressed by passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to CPAT output
#'
#' @importFrom tools file_path_sans_ext
#' @export

run_cpat <- function(bed_path, ref_fa, logit_model = NULL, hexamer_dat = NULL, logs_path = "default", quiet = FALSE) {
    #-----SETUP-----#
    # use default CPAT logit model and hexamer data if not provided by the user
    if (is.null(logit_model)) {
        logit_model <- system.file("extdata", "Human_train.RData", package = "ATRAIN")
    }
    if (is.null(hexamer_dat)) {
        hexamer_dat <- system.file("extdata", "Human_Hexamer.tab", package = "ATRAIN")
    }
    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(dirname(bed_path), "/run_cpat_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    #-----WORK-----#
    if (!quiet) {
        cat("\n*** Running CPAT ***\n\n")
    }
    cpat_path <- paste0(file_path_sans_ext(bed_path), ".cpat")
    if (!quiet) {
        cat(paste0("    ", Sys.time(), "\n"))
        cat("    Calling cpat.py ...")
    }
    cmd <- "cpat.py"
    if (Sys.which(cmd) == "") {
        stop("cpat.py was not found on the system path. Please it to the path and try again.")
    }
    args <- c("-d", logit_model,
              "-r", ref_fa,
              "-x", hexamer_dat,
              "-g", bed_path,
              "-o", cpat_path)
     system2(cmd, args)
     if (!quiet) {
         cat(" done\n")
         cat("\n    File (", basename(cpat_path),  ") written to: ", dirname(cpat_path), "\n", sep = "")
         cat("_____________________________________________________________________________\n")
     }
     if (!is.null(logs_path)) {
         sink()
     }
     invisible(cpat_path)
}
