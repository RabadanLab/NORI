#' Calculate RPKM
#'
#' @param gtf_path file path to GTF input
#' @param bam_paths character vector of file paths to bam files
#' @param nthreads number of cores to use for parallelized foreach call
#'
#' @return NULL
#'
#' @export
bed_to_gtf_by_gene_annot <- function(bed_path) {

    # since we want to run featureCounts at the gene level, we first need to summarize the data to the gene level
    out <- summarize_to_gene_level(bed_path)
    bed_genes <- out$bed_genes
    bed_path_genes <- out$bed_path_genes

    # next we will convert the BED file to a GTF for featureCounts
    gtf <- bed_to_gtf(bed_genes)

    # write GTF because featureCounts only accepts GTF as a file
    gtf_path <- gsub(".bed", ".gtf", bed_path)
    write.table(gtf, file = gtf_path, quote = F, row.names = F, col.names = F, sep = "\t")

    gtf_path
}
