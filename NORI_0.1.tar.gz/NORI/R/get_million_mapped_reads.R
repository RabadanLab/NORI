#' Get million mapped reads
#'
#' Get million mapped reads using samtools idxstats. This function is called by \code{calculate_rpkm}
#'
#' @param param text
#'
#' @return return obj

#' @export
#' @import doParallel
#' @import data.table
get_million_mapped_reads <- function(bam_paths, num_cores = NULL)
{
    if (Sys.which("samtools") == "")
    {
        stop("samtools was not found on the system path.
            Please add it to the path and try again.")
    }
    if (!quiet) {
        cat("Getting million mapped reads. Using",
            doParallel::getDoParWorkers(), "cores\n")
    }
    doParallel::registerDoParallel(cores = num_cores)

    # get mapped reads in millions using samtools idxstats
    million_mapped_reads <- foreach (i = seq_along(bam_paths)) %dopar%
    {
        cmd <- paste("samtools idxstats", bam_paths[i], "| cut -f3")
        million_mapped_reads <- sum(fread(cmd)$V1/1e6)
        names(million_mapped_reads) <- gsub(pattern = ".bam", replacement = "",
            basename(bam_paths[i]))
        return(million_mapped_reads)
    }
    return(million_mapped_reads)
}
