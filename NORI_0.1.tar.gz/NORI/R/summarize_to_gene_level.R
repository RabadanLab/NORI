#' Summarize to gene level
#'
#' @param gtf_path file path to GTF input
#' @param bam_paths character vector of file paths to bam files
#' @param num_cores number of cores to use for parallelized foreach call
#'
#' @return NULL
#'
#' @export
#' @import data.table
summarize_to_gene_level <- function(bed_path) {
    # 1. sort BED by chrom and start for bedtools
    bed <- fread(bed_path)
    bed_sorted <- bed[order(V1, V2)] # 1st and 2nd cols of BED files are chrom and start
    bed_path_sorted <- paste0(gsub(".bed", "", bed_path), "_sorted.bed")
    write.table(bed_sorted, file = bed_path_sorted, quote = FALSE, row.names = FALSE, col.names = FALSE, sep = "\t")

    # 2. run bedtools cluster to get overlapping intervals (gene level) and capture output
    bed_genes <- system(paste("bedtools cluster -i", bed_path_sorted), intern = TRUE) # returns char list sep by \t
    bed_genes <- fread(paste(bed_genes, collapse = "\n"), sep = "\t") # add newlines (\n) and read char list into data table
    setnames(bed_genes, c("chrom", "start", "end", "transcript_id", "score",
        "strand", "thickStart", "thickEnd", "rgb", "blockCount", "blockSizes",
        "blockStarts", "gene_num"))
    bed_genes[, gene_id := paste0("LNC", gene_num)][, gene_num := NULL]
    bed_path_genes <- paste0(gsub(".bed", "", bed_path), "_genes.bed")

    write.table(bed_genes, file = bed_path_genes, quote = F, row.names = F, col.names = F, sep = "\t")

    list("bed_genes" = bed_genes, "bed_path_genes" = bed_path_genes)
}
