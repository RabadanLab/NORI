#' Convert GTF to BED
#'
#' This function converts a GTF to BED12 file, saves the output,
#' and returns the path to the file
#'
#' @param gtf_path file path to GTF input
#' @param output_dir optional output directory. Defaults to same directory as GTF input.
#' Will be created if it does not already exist.
#' @param logs_path optional path to log file. Defaults to "gtf_to_bed_log" saved in
#' the output directory specified by \code{output_dir}. Logs can be suppressed by
#' passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to resulting BED file
#'
#' @import data.table
#' @importFrom tools file_ext
#' @export

gtf_to_bed <- function(gtf_path, output_dir = NULL, logs_path = "default", quiet = FALSE) {

    stopifnot(file.exists(gtf_path))

    # save output to same folder as gtf input if not specified
    if (is.null(output_dir)) {
        output_dir <- dirname(gtf_path)
    } else if (!file.exists(output_dir)) {
	   dir.create(output_dir)
    }

    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(output_dir, "/gtf_to_bed_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    if (!quiet){
        cat("\n*** Converting GTF to BED12  ***\n\n")
    }

    gtf <- fread(gtf_path, header = FALSE) # read gtf

    ## the next two steps take ~1.5 min for a 3e6 line gtf.
    # can parallelize or select transcript_id by regex to speed up
    attributes <- strsplit(gtf$V9, "; ", fixed = TRUE)

    # define function for vapply
    get_transcript_ids <- function(attributes) { # 9th col in GTF format must be an attribute list
        transcript_id <- attributes[2] # must be 2nd attribute. see GTF specifications
            # we can use this line if we want to be absolutely sure:
            # transcript_id <- attributes[grepl(pattern = "transcript_id", attributes)]
        transcript_id <- gsub(pattern = 'transcript_id |\"', replacement = '', transcript_id) # clean string
        transcript_id
    }

    # call vapply to extract transcript ids from GTF attributes list
    transcript_ids <- vapply(attributes, FUN = get_transcript_ids, FUN.VALUE = character(1))

    # # uncomment to run in parallel
    # # this will require adding: @import parallel to the roxygen header
    # num_cores <- detectCores()/4
    # transcript_ids <- mclapply(attributes, FUN = get_transcript_ids,)
    # transcript_ids <- unlist(transcript_ids)

    # append transcript id column for BED conversion
    gtf[, tmp_tids := transcript_ids]

    # create BED
    bed <- gtf[, .(chrom = unique(V1),
                   chromStart = min(V4) - 1, # 0-based indexing
                   chromEnd = max(V5),
                   name = tmp_tids,
                   score = unique(V6),
                   strand = unique(V7),
                   thickStart = min(V4) - 1,
                   thickEnd = max(V5),
                   itemRgb = 0,
                   blockCount = .N,
                   blockSizes = paste(V5 - V4 + 1, collapse = ","), # 0-based indexing
                   blockStarts = paste(V4 - V4[1], collapse = ",")),
                 by = "tmp_tids"][, tmp_tids := NULL]

    # write BED to file.
    if (file_ext(gtf_path) == "gtf") {
        bed_path <- paste0(output_dir, "/", gsub(pattern = ".gtf", replacement = ".bed", basename(gtf_path)))
    } else { # handle case where passed GTF file does not have a .gtf extension
        bed_path <- paste0(output_dir, "/", basename(gtf_path), ".bed")
    }
    write.table(bed, file = bed_path, quote = FALSE, row.names = FALSE, col.names = FALSE, sep = "\t")

    if (!quiet) {
        cat(" done\n")
        cat("\n    File (", basename(bed_path),  ") written to: ", dirname(bed_path), "\n", sep = "")
        cat("_____________________________________________________________________________\n")
    }
    if (!is.null(logs_path)) {
        sink()
    }

    invisible(bed_path)
}
