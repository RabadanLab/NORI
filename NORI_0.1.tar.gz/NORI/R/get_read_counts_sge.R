#' Get read counts using a Sun Grid Engine cluster
#'
#' @param gtf_path file path to GTF input
#' @param bam_paths character vector of file paths to bam files
#' @param num_cores number of cores to use for parallelized foreach call
#'
#' @export
#'
#' @return NULL

get_read_counts_sge <- function(bam_paths, gtf_path, output_dir,
    args = c("-p", "-s 0", "-B"), mem = 1, overwrite = TRUE, quiet = FALSE) {

    args <- paste(args, collapse = " ")
    logs_dir <- paste0(output_dir, '/logs')
    if (!file.exists(output_dir)) {
        dir.create(output_dir)
    }
    if (!file.exists(logs_dir)) {
        dir.create(logs_dir)
    }
    # write shell file to later be sent to the cluster
    get_read_counts_text <- c("#!/bin/bash",
                               paste0("#$ -l mem=", mem, "G"),
                               "#$ -cwd",
                               "",
                               "time1=$( date \"+%s\" )",
                               "echo [Directory] $(pwd)",
                               "echo [Machine] $(uname -n)",
                               "echo [Start] $(date)",
                               "echo [args] $*",
                               "",
                               "gtf=\"$1\"",
                               "bam_id=\"$2\"",
                               "bam_file=\"$3\"",
                               "out_dir=\"$4\"",
                               "",
                               "cd $out_dir",
                               "",
                               "echo \"Running:\"",
                               paste("echo \"featureCounts", args, "-t exon -g gene_id -a $gtf -o $bam_id $bam_file\""),
                               paste("featureCounts", args, "-t exon -g gene_id -a $gtf -o $bam_id $bam_file"),
                               "",
                               "time2=$( date \"+%s\" )",
                               "echo [deltat] $(( $time2 - $time1 ))",
                               "echo [End] $(date)")

    get_read_counts_file <- paste0(output_dir, "/get_read_counts.sh")
    write.table(get_read_counts_text, file = get_read_counts_file,
                row.names = FALSE, col.names = FALSE, quote = FALSE)

    # send files to the cluster
    for (bam_path in bam_paths) {
        bam_name <- gsub("[.]bam", "", basename(bam_path))
        system(paste("qsub -e", logs_dir, "-o", logs_dir, get_read_counts_file,
            gtf_path, bam_name, bam_path, output_dir))
    }
}
