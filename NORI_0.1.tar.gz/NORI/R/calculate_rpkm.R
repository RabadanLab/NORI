#' Calculate RPKM
#'
#' This function calculates the Reads Per Kilobase of transcript per Million mapped reads
#'
#' @param bed_path file path to BED input
#' @param bam_paths character vector of file paths to bam files
#' @param write_rpkm_to_file option to choose whether to write RPKM to file. Defaults to TRUE.
#' @param output_dir option to choose folder where output will be saved. Defaults to same folder as BED input
#' @param nthreads number of cores to use for parallelized foreach call
#'
#' @return NULL
#'
#' @export
#' @import Rsubread
#' @import data.table
calculate_rpkm <- function(bed_path, bam_paths, write_rpkm_to_file = TRUE, output_dir = NULL, nthreads = 1) {

    # save output to same folder as the BED input if not specified
    if (is.null(output_dir)) {
        output_dir <- dirname(bed_path)
    } else if (!file.exists(output_dir)) {
	   dir.create(output_dir)
    }

    # summarize transcript data to the gene level, convert BED to GTF, and return path
    # because featureCounts only accepts GTF file paths
    gtf_path <- bed_to_gtf_by_gene_annot(bed_path)

    # run featureCounts
    tmp <- featureCounts(files = bam_paths, annot.ext = gtf_path,
                    isGTFAnnotationFile = TRUE, GTF.featureType = "exon",
                    GTF.attrType = "gene_id", isPairedEnd = TRUE,
                    strandSpecific = 0,
                    requireBothEndsMapped = TRUE, nthreads = nthreads)

    # extract elements for and calculate rpkm
    reads <- tmp$counts
    kilobase_transcript <- tmp$annotation$Length / 1e3

    # get bam names
    bam_names <- gsub("[.]bam", "", basename(bam_paths))

    # convert from wide to long format
    reads <- data.table(rownames(reads), reads)
    setnames(reads, c("gene_id", bam_names))
    rpkm <- melt(reads, id.vars = "gene_id", variable.name = "sample", value.name = "reads")
    rpkm[, kilobase_transcript := kilobase_transcript]
    rpkm[, million_mapped_reads := sum(reads)/1e6, by = "sample"]
    rpkm[, rpkm := (reads / kilobase_transcript) / million_mapped_reads]

    if (write_rpkm_to_file) {
        write.table(rpkm, file = paste0(output_dir, "/rpkm.tsv"), quote = FALSE, row.names = FALSE, col.names = TRUE, sep = "\t")
    }

    list("rpkm" = rpkm, "bed_path_genes" = bed_path_genes)
}

# Rsubread options
# -p
# (isPairedEnd)
# If specified, fragments (or templates) will be counted instead of reads. This option is only applicable for paired-end reads.
#
# -s < int >
# (isStrandSpecific)
# Indicate if strand-specific read counting should be performed. It has three possible values: 0 (unstranded), 1 (stranded) and 2 (reversely stranded). 0 by default. For paired-end reads, strand of the first read is taken as the strand of the whole fragment and FLAG field of the current read is used to tell if it is the first read in the fragment.
#
# -O
# (allowMultiOverlap)
# If specified, reads (or fragments if -p is specified) will be allowed to be assigned to more than one matched meta-feature (or feature if -f is specified). Reads/fragments overlapping with more than one meta-feature/feature will be counted more than once. Note that when performing meta-feature level summarization, a read (or fragment) will still be counted once if it overlaps with multiple features belonging to the same meta-feature but does not overlap with other meta-features.
#
# -B
# (requireBothEndsMapped)
# If specified, only fragments that have both ends successfully aligned will be considered for summarization. This option should be used together with -p (or isPairedEnd in Rsubread featureCounts).
#
# -t < input >
# (GTF.featureType)
# Specify the feature type. Only rows which have the matched feature type in the provided GTF annotation file will be included for read counting. ‘exon’ by default
#
# -g < input >
# (GTF.attrType)
# Specify the attribute type used to group features (eg. exons) into meta-features (eg. genes) when GTF annotation is provided. ‘gene id’ by default. This attribute type is usually the gene identifier. This argument is useful for the meta-feature level summarization.
#
# -a < input >
# (annot.ext, annot.inbuilt)
# Give the name of an annotation file.
#
# http://bioinf.wehi.edu.au/subread-package/SubreadUsersGuide.pdf
