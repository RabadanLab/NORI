#' Candidate long noncoding RNA identification pipeline
#'
#' Send a transcriptome in GTF format through the NORI pipeline to identify
#' a set of candidate long noncoding RNA.
#'
#' @param gtf_path path to input transcriptome in GTF format
#' @param ens_path path to Ensembl genome assembly in GTF format
#' @param refseq_path path to RefSeq genome assembly in GTF or BED format
#' @param pseudo_path path to Pseudogenes build in BED format
#' @param ref_fa_path path reference genome in fasta format for CPAT
#' @param output_dir path to output directory. Will be created if it
#' does not already exist.
#' @param logs_path path to log file. Defaults to the file "NORI_log"
#' saved within the output directory specified by \code{output_dir}.
#' Logs can be suppressed by passing NULL
#' @param logit_model path to training model for CPAT. See vignette for
#' more information
#' @param hexamer_dat path to hexamer frequency table for CPAT. See vignette for
#' more information
#' @param nthreads specify number of threads used to compute read counts
#' @param rpkm_threshold specify lower limit of RPKM for transcripts to keep
#' @param overwrite choose whether existing NORI output should be overwritten
#' @param quiet suppress logs if TRUE
#' @param filter_gtf_to_bed set to FALSE to skip step
#' @param filter_monoexonic set to FALSE to skip step
#' @param filter_ensembl set to FALSE to skip step
#' @param filter_refseq set to FALSE to skip step
#' @param filter_pseudogenes set to FALSE to skip step
#' @param filter_cpat set to FALSE to skip step
#' @param filter_length set to FALSE to skip step
#' @param filter_rpkm set to FALSE to skip step. While \code{calculate_rpkm}
#' can receives the \code{nthreads} argument, it may be faster to calculate rpkm
#' separately. See the vignette for more information
#'
#' @return File path of lncRNA list (saved in BED12 file format)
#'
#' @importFrom tools file_path_sans_ext file_ext
#' @export

NORI <- function(gtf_path, ens_path, refseq_path, pseudo_path, ref_fa_path,
    bam_paths = NULL, output_dir = NULL, logs_path = "default",
    cpat_cutoff = NULL, logit_model = NULL, hexamer_dat = NULL,
    nthreads = NULL, rpkm_threshold = NULL,
    overwrite = TRUE, quiet = FALSE,
    filter_gtf_to_bed = TRUE,
    filter_monoexonic = TRUE,
    filter_ensembl = TRUE,
    filter_refseq = TRUE,
    filter_pseudogenes = TRUE,
    filter_cpat = TRUE,
    filter_length = TRUE,
    filter_rpkm = TRUE) {

    #-----SETUP-----#
    # ensure passed file paths exist
    stopifnot(file.exists(gtf_path))
    stopifnot(file.exists(ens_path))
    stopifnot(file.exists(refseq_path))
    stopifnot(file.exists(pseudo_path))
    stopifnot(file.exists(ref_fa_path))

    # ensure paths to BAM files are passed if RPKM is to be calculated
    if (is.null(bam_paths) & filter_rpkm == TRUE) {
        stop("BAM files are needed to calculate RPKM")
    }
    # default to cwd if output directory is not specified or create if
    # was specified but does not exist
    if (is.null(output_dir)) {
        cat("No output directory specified. Using the current directory")
        output_dir <- getwd()
    } else if (!file.exists(output_dir)) {
	   dir.create(output_dir)
    }
    # define logs_path if not specified
    if (logs_path == "default") {
        logs_path <- paste0(output_dir, "/NORI_log")
    }

    #-----WORK-----#
    # run each step unless suppressed by passing filter_... = FALSE
    num_steps_to_run <- sum(filter_gtf_to_bed, filter_monoexonic,
        filter_ensembl, filter_refseq, filter_pseudogenes, filter_cpat,
        filter_length, filter_rpkm)
    lncrna_paths <- vector("character", num_steps_to_run)
    i <- 1
    # GTF to BED
    if (filter_gtf_to_bed) {
        lncrna_paths[i] <- paste0(output_dir, '/', gsub(".gtf", ".bed", basename(gtf_path)))
        # only run if the file doesn't exist or if we want to overwrite it
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(gtf_to_bed(gtf_path, output_dir, logs_path, quiet))
        } else if (!quiet) {
            cat("BED file exists and overwrite is set to FALSE. Skipping GTF conversion to BED\n")
        }
        i <- i + 1
    }
    # Monoexonic
    if (filter_monoexonic) {
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_me.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(filter_monoexonic(lncrna_paths[i-1], logs_path, quiet))
        } else if (!quiet) {
            cat("Monoexonic output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    # Ensembl
    if (filter_ensembl) {
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_ens.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(filter_ensembl(lncrna_paths[i-1], ens_path, NULL, logs_path, quiet))
        } else if (!quiet) {
            cat("Ensembl output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    # RefSeq
    if (filter_refseq) {
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_ref.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(filter_refseq(lncrna_paths[i-1], refseq_path, NULL, logs_path, quiet))
        } else if (!quiet) {
            cat("RefSeq output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    # Pseudogenes
    if (filter_pseudogenes) {
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_pseu.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(filter_pseudo(lncrna_paths[i-1], pseudo_path, NULL, logs_path, quiet))
        } else if (!quiet) {
            cat("Pseudogenes output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    # Length
    if (filter_length) {
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_length.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(filter_length(lncrna_paths[i-1], logs_path, quiet))
        } else if (!quiet) {
            cat("Length output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    # CPAT
    if (filter_cpat) {
        cpat_path <- paste0(file_path_sans_ext(lncrna_paths[i-1]), ".cpat")
        if (overwrite | !file.exists(cpat_path)) {
            try(run_cpat(lncrna_paths[i-1], ref_fa_path, logit_model, hexamer_dat, logs_path, quiet))
        }
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_cpat.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            try(filter_cpat(lncrna_paths[i-1], cpat_path, cpat_cutoff, logs_path, quiet))
        } else if (!quiet) {
            cat("CPAT output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    # RPKM
    if (filter_rpkm) {
        lncrna_paths[i] <- paste0(file_path_sans_ext(lncrna_paths[i-1]), "_bygene_rpkm.", file_ext(lncrna_paths[i-1]))
        if (!file.exists(lncrna_paths[i]) | overwrite) {
            out <- calculate_rpkm(lncrna_paths[i-1], bam_paths, write_rpkm_to_file = TRUE, nthreads)
            rpkm <- out$rpkm; bed_path_genes <- out$bed_path_genes

            filter_rpkm(rpkm, bed_path_genes, filter_by = "gene", rpkm_threshold = rpkm_threshold,
                logs_path = logs_path, quiet = quiet)
        } else if (!quiet) {
            cat("RPKM output exists and overwrite is set to FALSE. Skipping this step...\n")
        }
        i <- i + 1
    }
    invisible(lncrna_paths)
}
