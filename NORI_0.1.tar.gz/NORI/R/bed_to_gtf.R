#' Convert BED with gene_id to GTF
#'
#' description here
#'
#' @param gtf_path file path to GTF input
#' @param bam_paths character vector of file paths to bam files
#' @param num_cores number of cores to use for parallelized foreach call
#'
#' @return NULL
#'
#' @export
#' @import data.table

bed_to_gtf <- function(bed) {

    # define function to be run within apply
    bed13_to_gtf <- function(bed) {
        # assume BED13 for now (BED12 with gene_id)
        transcript_id <- bed[['transcript_id']]
        gene_id <- bed[['gene_id']]
        block_sizes <- as.numeric(unlist(strsplit(bed[['blockSizes']], ",")))
        block_starts <- as.numeric(unlist(strsplit(bed[['blockStarts']], ",")))

        chrom <- bed[['chrom']]
        source <- "BED"
        feature <- "exon"
        start <- as.numeric(bed[['start']]) + 1 # 1-based indexing
        end <- as.numeric(bed[['end']])
        score <- bed[['score']]
        strand <- bed[['strand']]
        frame <- "."

        exon_num <- 1
        out <- vector("list", length(block_starts))

        for (i in seq_along(block_starts)) {
            exon_start <- start + block_starts[i]
            exon_end <- start + block_starts[i] + block_sizes[i] - 1
            out[[i]] <- list(chrom, source, feature, exon_start, exon_end, score, strand, frame, paste0("gene_id ", '"', gene_id, '"', "; ", "transcript_id ", '"', transcript_id, '"', "; ", "exon_number ", '"', exon_num, '"'))
            exon_num <- exon_num + 1
        }
        rbindlist(out)
    }

    # apply over the row margin (1)
    # this means apply the function above to each row of the data table
    tmp <- apply(bed, 1, bed13_to_gtf)
    gtf <- rbindlist(tmp)
    gtf
}
