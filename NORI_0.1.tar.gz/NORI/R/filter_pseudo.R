#' Remove transcripts annotated as pseudogenes in Pseudogenes.org
#'
#' @param bed_path path to BED file
#' @param ref_path path to pseudogenes build in BED format
#' @param intersect_args additional arguments to be sent to bedtools intersect. "-nonamecheck", "-split", and "-v" are automatically passed.
#' @param logs_path path to log file. Defaults to the file "pseudo_log" saved in the same directory as \code{bed_path}. Logs can be suppressed by passing NULL
#' @param quiet suppress logs if TRUE
#'
#' @return path to resulting BED file
#'
#' @importFrom tools file_path_sans_ext file_ext
#' @import data.table
#' @export

filter_pseudo <- function(bed_path, ref_path, intersect_args = NULL, logs_path = "default", quiet = FALSE) {
    # write logs if not suppressed by passing NULL
    if (!is.null(logs_path)) {
        # set logs_path if not specified
        if (logs_path == "default") {
            logs_path <- paste0(dirname(bed_path), "/pseudo_log")
        }
        sink(file = logs_path, append = TRUE, split = TRUE)
    }
    if (!quiet) {
        cat("\n*** Filtering transcripts found in specified pseudogenes build ***\n")
    }
    # check if chromosome naming scheme is "chr1", "chr2",... or "1", "2", ...
    ref <- unique(fread(ref_path, header = FALSE))
    starts_with_chr <- ref[, any(grepl(pattern = "^chr[1-9]", V1))]

    if (!starts_with_chr) {
        ref[, V1 := paste0("chr", V1)]
        write.table(ref, file = ref_path, quote = FALSE, row.names = FALSE, col.names = FALSE, sep = "\t")
    }

    if (!quiet) {
        cat("    Calling bedtools intersect...")
    }
    # intersect filtered gtf with pseudogenes
    out_path <- paste0(file_path_sans_ext(bed_path), "_pseu.", file_ext(bed_path))
    bedtools_intersect(a = bed_path, b = ref_path,
        out_path = out_path, args = c("-nonamecheck", "-split", "-v", intersect_args))
    if (!quiet) {
        cat(" done\n")
        num_lines_bed <- strsplit(system(paste("wc -l", bed_path),
            intern = TRUE), split = ' ')[[1]][1]
        num_lines_ref <- strsplit(system(paste("wc -l", ref_path),
            intern = TRUE), split = ' ')[[1]][1]
        num_lines_out <- strsplit(system(paste("wc -l", out_path),
            intern = TRUE), split = ' ')[[1]][1]
        cat("\n    Summary\n",
            "    Inputs\n        ",
            basename(bed_path), ":", num_lines_bed, "transcripts\n        ",
            basename(ref_path), ":", num_lines_ref, "transcripts\n",
            "    Output\n        ",
            basename(out_path), ":", num_lines_out, "transcripts\n\n")
        cat("\n    File (", basename(out_path),  ") written to: ", dirname(out_path), "\n", sep = "")
        cat("_____________________________________________________________________________\n")
    }
    if (!is.null(logs_path)) {
        sink()
    }
    invisible(out_path)
}
